package pervasive.jku.at.handshakesensor;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;

/**
 * Created by yh-banend on 26.06.17.
 */

public class shakeDetector implements SensorEventListener {

    private static final float HANDSHAKE_THRESHOLDGRAVITY = 0.9F;
    private static final int HANDSHAKE_SLOP_TIME_MS=500;
    private static final int HANDSHAKE_COUNT_RESET_TIME_MS=3000;

    private OnShakeListener mListener;
    private long mHandshakeTimestamp;
    private int mHandshakeCount;

    private static final String TAG = "HandShakeSensor";


    public void setOnShakeListener(OnShakeListener listener){
        this.mListener=listener;
    }

    public interface OnShakeListener{
        public void onShake(int count);
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d(TAG,"shake sensor.");
        if(mListener != null){
            float hsx= event.values[0];
            float hsy= event.values[1];
            float hsz= event.values[2];

            float gX = hsx / SensorManager.GRAVITY_EARTH;
            float gY = hsy / SensorManager.GRAVITY_EARTH;
            float gZ = hsz / SensorManager.GRAVITY_EARTH;

            //gravity will be close to 1 when no movement.
            float gForce = (float)Math.sqrt(gX * gX + gY * gY + gZ * gZ);

            Log.d(TAG,"gForce is: "+gForce);
            if (gForce > HANDSHAKE_THRESHOLDGRAVITY){
                final long now = System.currentTimeMillis();
                Log.d(TAG, "now: "+now);
                if (mHandshakeTimestamp + HANDSHAKE_SLOP_TIME_MS > now){
                    return;
                }

                if (mHandshakeTimestamp + HANDSHAKE_COUNT_RESET_TIME_MS < now){
                    mHandshakeCount = 0;
                }

                mHandshakeTimestamp = now;
                mHandshakeCount++;
                Log.d(TAG,"hand shake count: "+mHandshakeCount);
                mListener.onShake(mHandshakeCount);
            }
        }else {
            Log.d(TAG, "listener is empty");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
