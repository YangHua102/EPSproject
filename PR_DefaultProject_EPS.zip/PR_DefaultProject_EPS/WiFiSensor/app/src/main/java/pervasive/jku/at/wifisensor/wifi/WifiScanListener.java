package pervasive.jku.at.wifisensor.wifi;

public interface WifiScanListener {
    void onWifiChanged(WifiScanEvent event);
}
